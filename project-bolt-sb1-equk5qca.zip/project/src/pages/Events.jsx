import { useEffect } from 'react'
import { Link } from 'react-router-dom'
import { Users, Music, Utensils, Gift } from 'lucide-react'
import './Events.css'

export default function Events() {
  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])

  const eventTypes = [
    {
      icon: Gift,
      title: 'Birthday Parties',
      description: 'Make your special day unforgettable',
      features: ['Custom menu', 'DJ & Music', 'Decorations', 'Cake arrangement'],
    },
    {
      icon: Users,
      title: 'Anniversaries',
      description: 'Celebrate love with style',
      features: ['Romantic ambiance', 'Personalized menu', 'Special arrangements', 'Photography'],
    },
    {
      icon: Music,
      title: 'Corporate Events',
      description: 'Professional gatherings made elegant',
      features: ['Meeting facilities', 'Catering', 'Audio-visual setup', 'Dedicated staff'],
    },
    {
      icon: Utensils,
      title: 'Private Dinners',
      description: 'Exclusive dining experiences',
      features: ['Private space', 'Curated menu', 'Wine pairing', 'Personal touch'],
    },
  ]

  return (
    <div className="events-page">
      <section className="page-hero">
        <div className="page-hero-content">
          <h1>Events & Banquets</h1>
          <p>Your Perfect Celebration Venue</p>
        </div>
      </section>

      <section className="events-intro">
        <div className="container">
          <div className="intro-card">
            <h2>Why Choose Mezza 9?</h2>
            <div className="intro-grid">
              <div className="intro-item">
                <div className="intro-icon">🏛️</div>
                <h3>Grand Ambiance</h3>
                <p>Spacious venue with elegant décor</p>
              </div>
              <div className="intro-item">
                <div className="intro-icon">👥</div>
                <h3>Capacity</h3>
                <p>250–300 Guests</p>
              </div>
              <div className="intro-item">
                <div className="intro-icon">🎵</div>
                <h3>Entertainment</h3>
                <p>In-house DJ & Dance Floor</p>
              </div>
              <div className="intro-item">
                <div className="intro-icon">👨‍🍳</div>
                <h3>Cuisine</h3>
                <p>8 World Cuisines Available</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="event-types">
        <div className="container">
          <h2 className="section-heading">Our Event Services</h2>
          <div className="event-types-grid">
            {eventTypes.map((event, idx) => {
              const Icon = event.icon
              return (
                <div key={idx} className="event-type-card">
                  <div className="event-type-icon">
                    <Icon size={40} />
                  </div>
                  <h3>{event.title}</h3>
                  <p className="event-description">{event.description}</p>
                  <ul className="event-features">
                    {event.features.map((feature, i) => (
                      <li key={i}>{feature}</li>
                    ))}
                  </ul>
                </div>
              )
            })}
          </div>
        </div>
      </section>

      <section className="packages-section">
        <div className="container">
          <h2 className="section-heading">Our Packages</h2>
          <div className="packages-grid">
            <PackageCard
              name="Basic"
              price="₹1,200"
              perPerson="per person"
              features={[
                'Seating for up to 50 guests',
                'Multi-cuisine menu',
                'Standard decor',
                'Complimentary water & tea',
              ]}
            />
            <PackageCard
              name="Premium"
              price="₹1,800"
              perPerson="per person"
              highlight
              features={[
                'Seating for up to 150 guests',
                'Multi-cuisine menu',
                'Premium decor',
                'DJ & Dance floor',
                'Photography',
                'Beverages included',
              ]}
            />
            <PackageCard
              name="Grand"
              price="₹2,500"
              perPerson="per person"
              features={[
                'Seating for 250-300 guests',
                '8 World cuisines',
                'Premium decor & lighting',
                'DJ & Professional MC',
                'Full photography',
                'Bar service',
                'Valet parking',
              ]}
            />
          </div>
        </div>
      </section>

      <section className="banquet-info">
        <div className="container">
          <div className="info-grid">
            <div className="info-box">
              <h3>Minimum Guests</h3>
              <p className="highlight">15 Guests</p>
            </div>
            <div className="info-box">
              <h3>Maximum Capacity</h3>
              <p className="highlight">250–300 Guests</p>
            </div>
            <div className="info-box">
              <h3>Timing Flexibility</h3>
              <p className="highlight">Open Daily 11:30 AM – 1:00 AM</p>
            </div>
            <div className="info-box">
              <h3>Customization</h3>
              <p className="highlight">Fully Customizable Menus</p>
            </div>
          </div>
        </div>
      </section>

      <section className="event-features">
        <div className="container">
          <h2 className="section-heading">What's Included</h2>
          <div className="features-list">
            <div className="feature-item">
              <span className="feature-check">✓</span>
              <span>Private or Semi-Private Dining Space</span>
            </div>
            <div className="feature-item">
              <span className="feature-check">✓</span>
              <span>Dedicated Event Coordinator</span>
            </div>
            <div className="feature-item">
              <span className="feature-check">✓</span>
              <span>Customized Menu & Tasting</span>
            </div>
            <div className="feature-item">
              <span className="feature-check">✓</span>
              <span>In-house DJ & Dance Floor</span>
            </div>
            <div className="feature-item">
              <span className="feature-check">✓</span>
              <span>Professional Photography Option</span>
            </div>
            <div className="feature-item">
              <span className="feature-check">✓</span>
              <span>Parking Facility</span>
            </div>
          </div>
        </div>
      </section>

      <section className="event-cta">
        <div className="container">
          <h2>Ready to Plan Your Event?</h2>
          <p>Let our event team create an unforgettable experience for you</p>
          <div className="cta-buttons">
            <Link to="/contact" className="btn btn-primary">Schedule a Consultation</Link>
            <a href="tel:+918888851818" className="btn btn-secondary">Call +91 88888 51818</a>
          </div>
        </div>
      </section>
    </div>
  )
}

function PackageCard({ name, price, perPerson, features, highlight }) {
  return (
    <div className={`package-card ${highlight ? 'highlight' : ''}`}>
      {highlight && <div className="package-badge">Most Popular</div>}
      <h3 className="package-name">{name}</h3>
      <div className="package-price">
        <span className="price-value">{price}</span>
        <span className="price-label">{perPerson}</span>
      </div>
      <ul className="package-features">
        {features.map((feature, idx) => (
          <li key={idx}>
            <span className="feature-mark">✓</span>
            <span>{feature}</span>
          </li>
        ))}
      </ul>
      <a href="tel:+918888851818" className={`btn ${highlight ? 'btn-primary' : 'btn-secondary'}`}>
        Inquire Now
      </a>
    </div>
  )
}
