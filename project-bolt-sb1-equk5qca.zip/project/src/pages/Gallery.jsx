import { useState, useEffect } from 'react'
import { X } from 'lucide-react'
import './Gallery.css'

export default function Gallery() {
  const [selectedImage, setSelectedImage] = useState(null)

  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])

  const galleryImages = [
    { url: 'https://images.unsplash.com/photo-1517457373614-b7152f800529?w=600&h=400&fit=crop', alt: 'Restaurant ambiance' },
    { url: 'https://images.unsplash.com/photo-1504674900769-8af64e44f1e9?w=600&h=400&fit=crop', alt: 'Fine dining' },
    { url: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=600&h=400&fit=crop', alt: 'Food presentation' },
    { url: 'https://images.unsplash.com/photo-1518895949257-7621c3c786d7?w=600&h=400&fit=crop', alt: 'Interior design' },
    { url: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=600&h=400&fit=crop', alt: 'Dish plating' },
    { url: 'https://images.unsplash.com/photo-1585821155050-bc8ab570f13e?w=600&h=400&fit=crop', alt: 'Signature dishes' },
    { url: 'https://images.unsplash.com/photo-1519167758993-a0e58ff9bc60?w=600&h=400&fit=crop', alt: 'Event setup' },
    { url: 'https://images.unsplash.com/photo-1478895143208-ef9183e8b5aa?w=600&h=400&fit=crop', alt: 'Culinary art' },
    { url: 'https://images.unsplash.com/photo-1612528443702-f6741f70a049?w=600&h=400&fit=crop', alt: 'Appetizers' },
  ]

  return (
    <div className="gallery-page">
      <section className="page-hero">
        <div className="page-hero-content">
          <h1>Gallery</h1>
          <p>Glimpses of Our Culinary Excellence</p>
        </div>
      </section>

      <section className="gallery-section">
        <div className="container">
          <p className="gallery-intro">
            Explore the ambiance, cuisine, and experience that makes Mezza 9 special
          </p>
          <div className="gallery-grid">
            {galleryImages.map((image, idx) => (
              <div
                key={idx}
                className="gallery-item"
                onClick={() => setSelectedImage(image)}
              >
                <img
                  src={image.url}
                  alt={image.alt}
                  loading="lazy"
                />
                <div className="gallery-overlay">
                  <button className="view-btn">View</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {selectedImage && (
        <div className="lightbox" onClick={() => setSelectedImage(null)}>
          <button className="lightbox-close" onClick={() => setSelectedImage(null)}>
            <X size={32} />
          </button>
          <img src={selectedImage.url} alt={selectedImage.alt} />
        </div>
      )}
    </div>
  )
}
