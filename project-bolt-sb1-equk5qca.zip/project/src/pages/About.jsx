import { useEffect } from 'react'
import { Award, Users, Clock } from 'lucide-react'
import './About.css'

export default function About() {
  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])

  return (
    <div className="about-page">
      <section className="page-hero">
        <div className="page-hero-content">
          <h1>About Mezza 9</h1>
          <p>A 16-Year Legacy of Excellence</p>
        </div>
      </section>

      <section className="about-intro">
        <div className="container">
          <div className="about-grid">
            <div className="about-image">
              <img src="https://images.unsplash.com/photo-1517457373614-b7152f800529?w=500&h=600&fit=crop" alt="Restaurant" />
            </div>
            <div className="about-content">
              <h2>Our Story</h2>
              <p>
                Since 2008, Mezza 9 has been a beacon of culinary excellence in Hinjawadi. What started as a humble dream to bring the finest cuisines from around the world to Pune has blossomed into one of the city's most beloved dining destinations.
              </p>
              <p>
                From intimate family dinners to grand corporate celebrations, we've created countless memorable moments. Our commitment to quality, innovation, and hospitality has earned us the trust of over 10,000 happy guests and a stellar 4.0★ rating on Zomato.
              </p>
              <p>
                Today, we're proud to serve 8 world cuisines under one roof, accommodating 250–300 guests in our grand ambiance, with a dedicated team that treats every guest like family.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="highlights">
        <div className="container">
          <div className="highlights-grid">
            <div className="highlight-card">
              <Award size={40} />
              <h3>16+ Years</h3>
              <p>Of Culinary Excellence</p>
            </div>
            <div className="highlight-card">
              <Users size={40} />
              <h3>10,000+</h3>
              <p>Happy Guests Served</p>
            </div>
            <div className="highlight-card">
              <Clock size={40} />
              <h3>250-300</h3>
              <p>Guest Capacity</p>
            </div>
            <div className="highlight-card">
              <Award size={40} />
              <h3>4.0★</h3>
              <p>Zomato Rating</p>
            </div>
          </div>
        </div>
      </section>

      <section className="why-mezza">
        <div className="container">
          <h2 className="section-heading">Why Choose Mezza 9?</h2>
          <div className="why-grid">
            <div className="why-card">
              <div className="why-icon">👨‍🍳</div>
              <h3>Expert Chefs</h3>
              <p>Our culinary team brings years of expertise in crafting world-class dishes</p>
            </div>
            <div className="why-card">
              <div className="why-icon">🌍</div>
              <h3>8 World Cuisines</h3>
              <p>From North Indian to Continental, we have something for everyone</p>
            </div>
            <div className="why-card">
              <div className="why-icon">🏛️</div>
              <h3>Grand Ambiance</h3>
              <p>Elegant décor and spacious dining create the perfect atmosphere</p>
            </div>
            <div className="why-card">
              <div className="why-icon">⭐</div>
              <h3>Quality Ingredients</h3>
              <p>We source the finest ingredients for every dish</p>
            </div>
            <div className="why-card">
              <div className="why-icon">🎵</div>
              <h3>Entertainment</h3>
              <p>In-house DJ and dance floor for your celebrations</p>
            </div>
            <div className="why-card">
              <div className="why-icon">🤝</div>
              <h3>Hospitality</h3>
              <p>Dedicated staff ensuring your comfort and satisfaction</p>
            </div>
          </div>
        </div>
      </section>

      <section className="mission">
        <div className="container">
          <h2>Our Mission</h2>
          <p>
            To create memorable dining experiences where every plate tells a story, every guest feels valued, and every occasion becomes a cherished memory. We believe that great food brings people together, and it's our privilege to be part of your celebrations.
          </p>
        </div>
      </section>

      <section className="values">
        <div className="container">
          <h2 className="section-heading">Our Values</h2>
          <div className="values-grid">
            <div className="value-card">
              <h3>Excellence</h3>
              <p>We strive for perfection in every aspect of our service</p>
            </div>
            <div className="value-card">
              <h3>Integrity</h3>
              <p>We believe in honest practices and transparent dealings</p>
            </div>
            <div className="value-card">
              <h3>Innovation</h3>
              <p>We constantly evolve to offer new and exciting experiences</p>
            </div>
            <div className="value-card">
              <h3>Community</h3>
              <p>We're committed to being part of the local community</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
