import { useEffect, useRef } from 'react'
import { Link } from 'react-router-dom'
import { Star, Users, TrendingUp, MapPin, Clock, DollarSign } from 'lucide-react'
import './Home.css'

export default function Home() {
  const observerRef = useRef(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('fade-up')
          }
        })
      },
      { threshold: 0.1 }
    )

    const elements = document.querySelectorAll('.observe')
    elements.forEach((el) => observer.observe(el))

    return () => observer.disconnect()
  }, [])

  return (
    <div className="home">
      <section className="hero">
        <div className="hero-overlay"></div>
        <div className="hero-content">
          <div className="fade-up">
            <div className="hero-badge">Hinjawadi's Finest • Since 2008</div>
            <h1>Where Every Occasion Becomes a Memory</h1>
            <p className="hero-subheading">Fine Dining · Banquets · Celebrations · Hinjawadi, Pune</p>
            <div className="hero-buttons">
              <Link to="/contact" className="btn btn-primary">Reserve a Table</Link>
              <Link to="/menu" className="btn btn-secondary">View Menu</Link>
            </div>
          </div>
        </div>
        <div className="hero-rating">
          <div className="rating-content">
            <div className="rating-stars">
              <Star size={16} fill="currentColor" />
              <Star size={16} fill="currentColor" />
              <Star size={16} fill="currentColor" />
              <Star size={16} fill="currentColor" />
              <Star size={16} />
            </div>
            <p>4.0★ Zomato • 4,641+ Reviews • 16 Years</p>
          </div>
        </div>
      </section>

      <section className="info-bar">
        <div className="container">
          <div className="info-grid">
            <div className="info-item observe">
              <Clock className="info-icon" />
              <div>
                <h4>Open Daily</h4>
                <p>11:30 AM – 1:00 AM</p>
              </div>
            </div>
            <div className="info-item observe">
              <Users className="info-icon" />
              <div>
                <h4>Seating Capacity</h4>
                <p>250+ Guests</p>
              </div>
            </div>
            <div className="info-item observe">
              <DollarSign className="info-icon" />
              <div>
                <h4>Average Cost</h4>
                <p>₹1,200 for Two</p>
              </div>
            </div>
            <div className="info-item observe">
              <MapPin className="info-icon" />
              <div>
                <h4>Location</h4>
                <p>IT Park, Hinjawadi</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="section-padding about-section observe">
        <div className="container">
          <div className="about-grid">
            <div className="about-images slide-in-left">
              <img src="https://images.unsplash.com/photo-1517457373614-b7152f800529?w=500&h=600&fit=crop" alt="Restaurant ambiance" className="about-img" />
              <img src="https://images.unsplash.com/photo-1518895949257-7621c3c786d7?w=500&h=600&fit=crop" alt="Fine dining experience" className="about-img" />
            </div>
            <div className="about-content slide-in-right">
              <div className="section-tag">Our Story</div>
              <h2 className="section-heading">A Legend in Hinjawadi for 16 Years</h2>
              <p>From intimate family dinners to grand corporate celebrations, Mezza 9 has been Pune's most beloved dining destination since 2008. Nestled in the heart of IT Park, we bring world cuisines together under one roof — where every plate tells a story and every visit feels like home.</p>
              <div className="about-stats">
                <div className="stat">
                  <h3>16+</h3>
                  <p>Years of Excellence</p>
                </div>
                <div className="stat">
                  <h3>8</h3>
                  <p>World Cuisines</p>
                </div>
                <div className="stat">
                  <h3>250+</h3>
                  <p>Seat Capacity</p>
                </div>
                <div className="stat">
                  <h3>10K+</h3>
                  <p>Happy Guests</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="section-padding cuisines-section observe">
        <div className="container">
          <div className="section-tag">Our Specialties</div>
          <h2 className="section-heading">8 World Cuisines, One Destination</h2>
          <div className="cuisines-grid">
            <div className="cuisine-card">
              <div className="cuisine-icon">🍛</div>
              <h3>North Indian</h3>
              <p>Authentic flavors, rich gravies</p>
            </div>
            <div className="cuisine-card">
              <div className="cuisine-icon">🍜</div>
              <h3>Asian & Oriental</h3>
              <p>From wok to table</p>
            </div>
            <div className="cuisine-card">
              <div className="cuisine-icon">🌮</div>
              <h3>Continental & Mexican</h3>
              <p>Global classics redefined</p>
            </div>
            <div className="cuisine-card">
              <div className="cuisine-icon">🦞</div>
              <h3>Seafood & Biryani</h3>
              <p>Fresh catch, aromatic rice</p>
            </div>
          </div>
        </div>
      </section>

      <section className="section-padding signature-dishes observe">
        <div className="container">
          <div className="section-tag">Must Try</div>
          <h2 className="section-heading">Our Signature Dishes</h2>
          <div className="dishes-grid">
            <DishCard
              image="https://images.unsplash.com/photo-1603786311174-d7f9fd95d7a3?w=400&h=300&fit=crop"
              name="Galouti Kebab"
              description="Melt-in-mouth Lucknowi classic"
              badge="Chef's Pick"
            />
            <DishCard
              image="https://images.unsplash.com/photo-1547592166-23ac45744acd?w=400&h=300&fit=crop"
              name="Tomato Basil Soup"
              description="House-made, slow-simmered"
              badge="Bestseller"
            />
            <DishCard
              image="https://images.unsplash.com/photo-1585821155050-bc8ab570f13e?w=400&h=300&fit=crop"
              name="Paneer Do Pyaza"
              description="Rich, spiced, unforgettable"
            />
            <DishCard
              image="https://images.unsplash.com/photo-1598103442097-8b74394b95c6?w=400&h=300&fit=crop"
              name="Seafood Sizzler"
              description="Theatrical, sizzling tableside"
            />
            <DishCard
              image="https://images.unsplash.com/photo-1599599810694-b5ac4dd77c4c?w=400&h=300&fit=crop"
              name="Chicken Starters"
              description="Tandoor-fresh, smoky perfection"
            />
            <DishCard
              image="https://images.unsplash.com/photo-1571115177098-24ec42ed204d?w=400&h=300&fit=crop"
              name="Tiramisu"
              description="Italian classic with a Mezza twist"
              badge="Must Try"
            />
          </div>
        </div>
      </section>

      <section className="section-padding events-section observe">
        <div className="container">
          <div className="section-tag">Celebrate With Us</div>
          <h2 className="section-heading">Your Perfect Celebration Venue</h2>
          <div className="events-grid">
            <div className="event-card">
              <div className="event-icon">🎂</div>
              <h3>Birthday Parties</h3>
            </div>
            <div className="event-card">
              <div className="event-icon">💍</div>
              <h3>Anniversaries</h3>
            </div>
            <div className="event-card">
              <div className="event-icon">🎓</div>
              <h3>Corporate Events</h3>
            </div>
            <div className="event-card">
              <div className="event-icon">🎊</div>
              <h3>Private Banquets</h3>
            </div>
          </div>
          <div className="highlight-box">
            <h3>Why Choose Mezza 9 for Events?</h3>
            <ul>
              <li>Capacity: 250–300 Guests</li>
              <li>Private DJ & Dance Floor</li>
              <li>Custom Menu Preparation</li>
              <li>Packages from ₹1,200/person</li>
              <li>Minimum 15 Guests</li>
              <li>Dedicated Event Coordinator</li>
            </ul>
            <Link to="/events" className="btn btn-primary">Plan Your Event</Link>
          </div>
        </div>
      </section>

      <section className="section-padding features-section observe">
        <div className="container">
          <div className="section-tag">Why We're Different</div>
          <h2 className="section-heading">The Mezza 9 Experience</h2>
          <div className="features-grid">
            <div className="feature-card">
              <div className="feature-check">✓</div>
              <h3>16+ Years of Excellence</h3>
            </div>
            <div className="feature-card">
              <div className="feature-check">✓</div>
              <h3>8 World Cuisines</h3>
            </div>
            <div className="feature-card">
              <div className="feature-check">✓</div>
              <h3>250+ Seat Grand Ambiance</h3>
            </div>
            <div className="feature-card">
              <div className="feature-check">✓</div>
              <h3>In-House DJ & Dance Floor</h3>
            </div>
            <div className="feature-card">
              <div className="feature-check">✓</div>
              <h3>Private Banquet Hall</h3>
            </div>
            <div className="feature-card">
              <div className="feature-check">✓</div>
              <h3>Prime IT Park Location</h3>
            </div>
          </div>
        </div>
      </section>

      <section className="section-padding testimonials-section observe">
        <div className="container">
          <div className="section-tag">Guest Voices</div>
          <h2 className="section-heading">What Our Guests Say</h2>
          <div className="testimonials-carousel">
            <TestimonialCard
              rating={5}
              text="A Legend in Hinjawadi with excellent management and hospitality. The menu is nicely designed and food quality is amazing. The service is top notch!"
              author="Rohan M."
              role="IT Professional, Pune"
            />
            <TestimonialCard
              rating={5}
              text="Amazing ambience, prompt service, and exceptional food. The Galouti Kebab alone is worth the visit. Easily the best place in Hinjawadi."
              author="Priya S."
              role="Food Blogger, Pune"
            />
            <TestimonialCard
              rating={5}
              text="Perfect for corporate dinners and family celebrations. The banquet service is excellent and the staff is always courteous and professional."
              author="Vikram T."
              role="Corporate Client"
            />
          </div>
          <div className="zomato-badge">
            <Star size={20} fill="currentColor" />
            <div>
              <p className="rating-value">4.0★ on Zomato</p>
              <p className="rating-count">4,641+ Reviews</p>
            </div>
          </div>
        </div>
      </section>

      <section className="cta-section observe">
        <div className="container">
          <h2>Ready for an Unforgettable Experience?</h2>
          <p>Reserve your table today and discover why Mezza 9 is Hinjawadi's most beloved restaurant</p>
          <Link to="/contact" className="btn btn-primary btn-large">Reserve Now</Link>
        </div>
      </section>
    </div>
  )
}

function DishCard({ image, name, description, badge }) {
  return (
    <div className="card">
      <img src={image} alt={name} className="card-image" loading="lazy" />
      <div className="dish-content">
        {badge && <span className="badge">{badge}</span>}
        <h3>{name}</h3>
        <p>{description}</p>
      </div>
    </div>
  )
}

function TestimonialCard({ rating, text, author, role }) {
  return (
    <div className="testimonial-card">
      <div className="testimonial-stars">
        {[...Array(rating)].map((_, i) => (
          <Star key={i} size={16} fill="currentColor" />
        ))}
      </div>
      <p className="testimonial-text">{text}</p>
      <p className="testimonial-author">{author}</p>
      <p className="testimonial-role">{role}</p>
    </div>
  )
}
