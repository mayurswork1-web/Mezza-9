import { useState, useEffect } from 'react'
import { MapPin, Phone, Clock, Mail } from 'lucide-react'
import './Contact.css'

export default function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    date: '',
    time: '',
    guests: '',
    occasion: '',
    request: '',
  })
  const [submitted, setSubmitted] = useState(false)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)

    try {
      const formBody = new FormData()
      formBody.append('access_key', '8fd2797d-a05a-4d8c-9de6-90c46ecebf0e')
      Object.keys(formData).forEach(key => {
        formBody.append(key, formData[key])
      })

      const response = await fetch('https://api.web3forms.com/submit', {
        method: 'POST',
        body: formBody,
      })

      if (response.ok) {
        setSubmitted(true)
        setFormData({
          name: '',
          phone: '',
          email: '',
          date: '',
          time: '',
          guests: '',
          occasion: '',
          request: '',
        })
        setTimeout(() => setSubmitted(false), 5000)
      }
    } catch (error) {
      console.error('Error:', error)
    } finally {
      setLoading(false)
    }
  }

  const timeSlots = []
  for (let h = 11; h <= 23; h++) {
    for (let m = 0; m < 60; m += 30) {
      if (h === 11 && m < 30) continue
      const hour = h === 23 && m > 0 ? '23' : String(h).padStart(2, '0')
      const minute = String(m).padStart(2, '0')
      const ampm = h >= 12 ? 'PM' : 'AM'
      const displayHour = h > 12 ? h - 12 : h
      timeSlots.push(`${displayHour}:${minute} ${ampm}`)
    }
  }

  return (
    <div className="contact-page">
      <section className="page-hero">
        <div className="page-hero-content">
          <h1>Contact & Reservations</h1>
          <p>Get in touch or book your table</p>
        </div>
      </section>

      <section className="contact-info-section">
        <div className="container">
          <div className="contact-grid">
            <div className="contact-info-card">
              <MapPin size={32} className="info-icon" />
              <h3>Location</h3>
              <p>Survey 152, IT Park Phase 1</p>
              <p>Opp KPIT Cummins, Hinjawadi</p>
              <p>Pune 411057</p>
              <a href="https://maps.google.com/?q=Survey+152+IT+Park+Phase+1+Hinjawadi+Pune" target="_blank" rel="noopener noreferrer" className="btn btn-secondary btn-small">
                View on Maps
              </a>
            </div>

            <div className="contact-info-card">
              <Phone size={32} className="info-icon" />
              <h3>Phone</h3>
              <p>+91 88888 51818</p>
              <p>Available 24/7</p>
              <a href="tel:+918888851818" className="btn btn-primary btn-small">Call Now</a>
            </div>

            <div className="contact-info-card">
              <Clock size={32} className="info-icon" />
              <h3>Timings</h3>
              <p>Open Daily</p>
              <p>11:30 AM – 1:00 AM</p>
              <p style={{ fontSize: '0.9rem', color: 'var(--text-muted)' }}>All Days</p>
            </div>

            <div className="contact-info-card">
              <Mail size={32} className="info-icon" />
              <h3>Email</h3>
              <p>reservations@mezza9.com</p>
              <p style={{ fontSize: '0.9rem', color: 'var(--text-muted)' }}>Quick Response</p>
            </div>
          </div>
        </div>
      </section>

      <section className="reservation-section">
        <div className="container">
          <div className="reservation-grid">
            <div className="reservation-form-wrapper">
              <div className="section-tag">Book Your Table</div>
              <h2 className="section-heading">Make a Reservation</h2>

              {submitted && (
                <div className="success-message">
                  <h3>Thank You!</h3>
                  <p>We'll confirm your table shortly. See you at Mezza 9!</p>
                </div>
              )}

              {!submitted && (
                <form onSubmit={handleSubmit} className="reservation-form">
                  <div className="form-group">
                    <label htmlFor="name">Full Name *</label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      required
                      placeholder="Your name"
                    />
                  </div>

                  <div className="form-row">
                    <div className="form-group">
                      <label htmlFor="phone">Phone Number *</label>
                      <input
                        type="tel"
                        id="phone"
                        name="phone"
                        value={formData.phone}
                        onChange={handleChange}
                        required
                        placeholder="Your phone"
                      />
                    </div>
                    <div className="form-group">
                      <label htmlFor="email">Email Address *</label>
                      <input
                        type="email"
                        id="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        required
                        placeholder="Your email"
                      />
                    </div>
                  </div>

                  <div className="form-row">
                    <div className="form-group">
                      <label htmlFor="date">Date *</label>
                      <input
                        type="date"
                        id="date"
                        name="date"
                        value={formData.date}
                        onChange={handleChange}
                        required
                      />
                    </div>
                    <div className="form-group">
                      <label htmlFor="time">Time *</label>
                      <select
                        id="time"
                        name="time"
                        value={formData.time}
                        onChange={handleChange}
                        required
                      >
                        <option value="">Select time</option>
                        {timeSlots.map((slot, idx) => (
                          <option key={idx} value={slot}>{slot}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="form-row">
                    <div className="form-group">
                      <label htmlFor="guests">Number of Guests *</label>
                      <select
                        id="guests"
                        name="guests"
                        value={formData.guests}
                        onChange={handleChange}
                        required
                      >
                        <option value="">Select guests</option>
                        {[...Array(21)].map((_, i) => (
                          <option key={i} value={i + 1 > 20 ? '20+' : i + 1}>
                            {i + 1 > 20 ? '20+' : i + 1}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="form-group">
                      <label htmlFor="occasion">Occasion</label>
                      <select
                        id="occasion"
                        name="occasion"
                        value={formData.occasion}
                        onChange={handleChange}
                      >
                        <option value="">Select occasion</option>
                        <option value="Regular Dining">Regular Dining</option>
                        <option value="Birthday">Birthday</option>
                        <option value="Anniversary">Anniversary</option>
                        <option value="Corporate">Corporate</option>
                        <option value="Other">Other</option>
                      </select>
                    </div>
                  </div>

                  <div className="form-group">
                    <label htmlFor="request">Special Request</label>
                    <textarea
                      id="request"
                      name="request"
                      value={formData.request}
                      onChange={handleChange}
                      placeholder="Any special requests or dietary requirements?"
                      rows="4"
                    ></textarea>
                  </div>

                  <button type="submit" className="btn btn-primary btn-large" disabled={loading}>
                    {loading ? 'Confirming...' : 'Confirm Reservation'}
                  </button>

                  <p className="form-note">Or call us: <a href="tel:+918888851818">+91 88888 51818</a></p>
                </form>
              )}
            </div>

            <div className="map-wrapper">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3783.5967345127556!2d73.74919!3d19.0863!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcde1d8e8e8e8e9%3A0x0!2sIT%20Park%20Phase%201%2C%20Hinjawadi%2C%20Pune!5e0!3m2!1sen!2sin!4v1234567890"
                width="100%"
                height="500"
                style={{ border: 0, borderRadius: '8px' }}
                allowFullScreen=""
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="Mezza 9 Location"
              ></iframe>
            </div>
          </div>
        </div>
      </section>

      <section className="faq-section">
        <div className="container">
          <h2 className="section-heading">Frequently Asked Questions</h2>
          <div className="faq-grid">
            <div className="faq-item">
              <h3>What's the minimum group size for reservations?</h3>
              <p>We welcome groups of 2 or more. For larger events (15+ guests), we recommend calling us for special arrangements.</p>
            </div>
            <div className="faq-item">
              <h3>Do you have vegetarian options?</h3>
              <p>Absolutely! We have an extensive vegetarian menu across all cuisines. Let us know your preferences.</p>
            </div>
            <div className="faq-item">
              <h3>Can we customize the menu?</h3>
              <p>Yes, we offer customized menus for groups and special events. Call us to discuss your requirements.</p>
            </div>
            <div className="faq-item">
              <h3>Is there parking available?</h3>
              <p>Yes, we have ample parking facilities available for all our guests.</p>
            </div>
            <div className="faq-item">
              <h3>What's your cancellation policy?</h3>
              <p>Cancellations made 24 hours before the reservation are accepted without any charges.</p>
            </div>
            <div className="faq-item">
              <h3>Do you serve alcohol?</h3>
              <p>Yes, we have a selection of beverages. BYOB is also welcome for events.</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
