import { useState, useEffect } from 'react'
import './Menu.css'

export default function Menu() {
  const [activeCategory, setActiveCategory] = useState('north-indian')
  const [items, setItems] = useState([])

  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])

  const menuData = {
    'north-indian': [
      { name: 'Galouti Kebab', description: 'Melt-in-mouth Lucknowi classic', price: '₹280' },
      { name: 'Paneer Do Pyaza', description: 'Rich paneer with peppers and onions', price: '₹320' },
      { name: 'Butter Chicken', description: 'Creamy tomato-based curry', price: '₹350' },
      { name: 'Dal Makhani', description: 'Slow-cooked lentils with cream', price: '₹260' },
      { name: 'Tandoori Chicken', description: 'Smoky, perfectly grilled', price: '₹380' },
      { name: 'Rogan Josh', description: 'Aromatic meat curry with spices', price: '₹340' },
    ],
    'biryani': [
      { name: 'Hyderabadi Biryani', description: 'Fragrant basmati rice with meat', price: '₹320' },
      { name: 'Lucknowi Biryani', description: 'Layered rice perfection', price: '₹300' },
      { name: 'Seafood Biryani', description: 'Fresh catch with aromatic rice', price: '₹380' },
      { name: 'Vegetable Biryani', description: 'Garden-fresh vegetables', price: '₹220' },
      { name: 'Egg Biryani', description: 'Soft-boiled eggs with rice', price: '₹250' },
    ],
    'seafood': [
      { name: 'Seafood Sizzler', description: 'Theatrical, sizzling tableside', price: '₹450' },
      { name: 'Tandoori Fish', description: 'Smoky fresh fish fillet', price: '₹420' },
      { name: 'Prawn Curry', description: 'Aromatic spiced prawns', price: '₹400' },
      { name: 'Butter Garlic Crab', description: 'Succulent crab in butter sauce', price: '₹480' },
      { name: 'Fish Tikka', description: 'Spiced and grilled to perfection', price: '₹380' },
    ],
    'continental': [
      { name: 'Lasagna', description: 'Layered pasta perfection', price: '₹320' },
      { name: 'Grilled Vegetables', description: 'Seasonal vegetables', price: '₹280' },
      { name: 'Caesar Salad', description: 'Crisp greens with parmesan', price: '₹220' },
      { name: 'Garlic Bread', description: 'Warm, buttery slices', price: '₹150' },
      { name: 'Mushroom Risotto', description: 'Creamy arborio rice', price: '₹340' },
    ],
    'appetizers': [
      { name: 'Tomato Basil Soup', description: 'House-made, slow-simmered', price: '₹180' },
      { name: 'Chicken Starters', description: 'Tandoor-fresh assortment', price: '₹280' },
      { name: 'Paneer Tikka', description: 'Grilled cottage cheese', price: '₹260' },
      { name: 'Spring Rolls', description: 'Crispy vegetable rolls', price: '₹200' },
      { name: 'Samosa', description: 'Spiced potato and peas', price: '₹120' },
    ],
    'desserts': [
      { name: 'Tiramisu', description: 'Italian classic with Mezza twist', price: '₹220' },
      { name: 'Gulab Jamun', description: 'Soft and syrupy', price: '₹180' },
      { name: 'Chocolate Cake', description: 'Rich and decadent', price: '₹200' },
      { name: 'Kheer', description: 'Traditional rice pudding', price: '₹160' },
      { name: 'Mango Cheesecake', description: 'Creamy and fruity', price: '₹240' },
    ],
  }

  useEffect(() => {
    setItems(menuData[activeCategory] || [])
  }, [activeCategory])

  const categories = [
    { id: 'north-indian', label: 'North Indian' },
    { id: 'biryani', label: 'Biryani' },
    { id: 'seafood', label: 'Seafood' },
    { id: 'continental', label: 'Continental' },
    { id: 'appetizers', label: 'Appetizers' },
    { id: 'desserts', label: 'Desserts' },
  ]

  return (
    <div className="menu-page">
      <section className="page-hero">
        <div className="page-hero-content">
          <h1>Our Menu</h1>
          <p>World-class cuisines crafted to perfection</p>
        </div>
      </section>

      <section className="menu-section">
        <div className="container">
          <div className="menu-categories">
            {categories.map((cat) => (
              <button
                key={cat.id}
                className={`category-btn ${activeCategory === cat.id ? 'active' : ''}`}
                onClick={() => setActiveCategory(cat.id)}
              >
                {cat.label}
              </button>
            ))}
          </div>

          <div className="menu-items-grid">
            {items.map((item, idx) => (
              <div key={idx} className="menu-item">
                <div className="menu-item-header">
                  <h3>{item.name}</h3>
                  <span className="menu-price">{item.price}</span>
                </div>
                <p className="menu-description">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="menu-cta">
        <div className="container">
          <h2>Can't decide? Let our staff recommend the best!</h2>
          <p>Visit us or call +91 88888 51818 for personalized recommendations</p>
          <a href="tel:+918888851818" className="btn btn-primary">Call Now</a>
        </div>
      </section>
    </div>
  )
}
