import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { Menu, X } from 'lucide-react'
import './Navbar.css'

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50)
    }
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  return (
    <nav className={`navbar ${scrolled ? 'scrolled' : ''}`}>
      <div className="navbar-container">
        <Link to="/" className="navbar-logo">
          Mezza 9
        </Link>

        <div className={`navbar-menu ${isOpen ? 'active' : ''}`}>
          <Link to="/" onClick={() => setIsOpen(false)} className="nav-link">Home</Link>
          <Link to="/menu" onClick={() => setIsOpen(false)} className="nav-link">Menu</Link>
          <Link to="/events" onClick={() => setIsOpen(false)} className="nav-link">Events</Link>
          <Link to="/gallery" onClick={() => setIsOpen(false)} className="nav-link">Gallery</Link>
          <Link to="/about" onClick={() => setIsOpen(false)} className="nav-link">About</Link>
          <Link to="/contact" onClick={() => setIsOpen(false)} className="nav-link">Contact</Link>
        </div>

        <Link to="/contact" className="btn btn-primary btn-small">
          Reserve Table
        </Link>

        <button
          className="hamburger"
          onClick={() => setIsOpen(!isOpen)}
          aria-label="Toggle menu"
        >
          {isOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>
    </nav>
  )
}
