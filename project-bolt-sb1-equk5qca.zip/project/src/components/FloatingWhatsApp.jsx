import { MessageCircle } from 'lucide-react'
import './FloatingWhatsApp.css'

export default function FloatingWhatsApp() {
  const whatsappLink = `https://wa.me/918888851818?text=${encodeURIComponent("Hi Mezza 9! I'd like to make a reservation.")}`

  return (
    <a
      href={whatsappLink}
      target="_blank"
      rel="noopener noreferrer"
      className="floating-whatsapp"
      aria-label="Chat on WhatsApp"
    >
      <MessageCircle size={32} />
    </a>
  )
}
