import { Link } from 'react-router-dom'
import { MapPin, Phone, Clock } from 'lucide-react'
import './Footer.css'

export default function Footer() {
  const currentYear = new Date().getFullYear()

  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-content">
          <div className="footer-col">
            <h3 className="footer-logo">Mezza 9</h3>
            <p className="footer-tagline">Where Every Occasion Becomes a Memory</p>
            <p className="footer-desc">Hinjawadi's finest since 2008</p>
            <div className="social-links">
              <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" aria-label="Instagram">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
                  <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37"></path>
                  <circle cx="17.5" cy="6.5" r="1.5"></circle>
                </svg>
              </a>
              <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" aria-label="Facebook">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M18 2h-3a6 6 0 0 0-6 6v3H7v4h2v8h4v-8h3l1-4h-4V8a2 2 0 0 1 2-2h1z"></path>
                </svg>
              </a>
            </div>
          </div>

          <div className="footer-col">
            <h4>Quick Links</h4>
            <ul>
              <li><Link to="/">Home</Link></li>
              <li><Link to="/menu">Menu</Link></li>
              <li><Link to="/events">Events & Banquets</Link></li>
              <li><Link to="/gallery">Gallery</Link></li>
              <li><Link to="/about">About Us</Link></li>
              <li><Link to="/contact">Contact</Link></li>
            </ul>
          </div>

          <div className="footer-col">
            <h4>Contact Info</h4>
            <div className="contact-item">
              <MapPin size={18} />
              <div>
                <p>Survey 152, IT Park Phase 1</p>
                <p>Opp KPIT Cummins, Hinjawadi</p>
                <p>Pune 411057</p>
              </div>
            </div>
            <div className="contact-item">
              <Phone size={18} />
              <a href="tel:+918888851818">+91 88888 51818</a>
            </div>
            <div className="contact-item">
              <Clock size={18} />
              <div>
                <p>Open Daily</p>
                <p>11:30 AM – 1:00 AM</p>
              </div>
            </div>
          </div>
        </div>

        <div className="footer-divider"></div>

        <div className="footer-bottom">
          <p>&copy; {currentYear} Mezza 9. All Rights Reserved.</p>
        </div>
      </div>
    </footer>
  )
}
